﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorCRUD_popup.Data;

namespace BlazorCRUD_popup.Services
{
    public class CarServices
    {
        protected readonly AppDbContext _dbContext;

        public CarServices(AppDbContext _db)
        {
            _dbContext = _db;
        }

        public List<CarClass> GetCars() => _dbContext.CarTable.ToList();

        public CarClass GetCarDetails(string modelName)
        {
            CarClass editObj = new CarClass();
            return _dbContext.CarTable.FirstOrDefault(u => u.ModelName == modelName);
        }

        public bool UpdateCar(CarClass updateDetails)
        {
            var GetCar = _dbContext.CarTable.FirstOrDefault(u => u.ModelName == updateDetails.ModelName);
            if (GetCar != null)
            {
                GetCar.CarManufacturer = updateDetails.CarManufacturer;
                GetCar.CarType = updateDetails.CarType;
                GetCar.ModelName = updateDetails.ModelName;
                GetCar.CountryManufacturer = updateDetails.CountryManufacturer;
                _dbContext.SaveChanges();
            }
            else
            {
                return false;
            }

            return true;

        }

        public bool DeleteCar(CarClass deleteDetails)
        {
            var GetCar = _dbContext.CarTable.FirstOrDefault(u => u.ModelName == deleteDetails.ModelName);
            if (GetCar != null)
            {
                _dbContext.Remove(GetCar);
                _dbContext.SaveChanges();
            }
            else
            {
                return false;
            }

            return true;
        }
        public bool AddCar(CarClass carAdd)
        {
            _dbContext.CarTable.Add(carAdd);
            _dbContext.SaveChanges();
            return true;
        }
    }
}
