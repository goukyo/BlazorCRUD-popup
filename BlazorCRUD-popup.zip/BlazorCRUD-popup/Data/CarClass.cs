﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD_popup.Data
{
    public class CarClass
    {
        [Key] 
        public int Id { get; set; }
        public string CarManufacturer { get; set; }
        public string ModelName { get; set; }
        public string CarType { get; set; }
        public string CountryManufacturer { get; set; }
    }
}
